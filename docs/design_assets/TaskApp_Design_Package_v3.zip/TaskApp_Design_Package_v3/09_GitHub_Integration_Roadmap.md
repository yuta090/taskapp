# GitHub Integration Roadmap
Phase1: PR linking, optional merge->done
Phase2: issues import, write-back (TBD)
