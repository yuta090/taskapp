# UI Design System Rules
(unchanged; keep as your v2 constitution)
