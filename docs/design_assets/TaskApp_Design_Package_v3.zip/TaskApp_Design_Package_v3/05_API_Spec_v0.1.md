# API Spec v0.1 (logical)

Client reads MUST use snapshot tables:
- milestone_publications (is_published=true)
- task_publications (only within published milestones)
- wiki_page_publications (only within published milestones)

Client writes:
- discussion_comments insert only (scoped by RLS)
