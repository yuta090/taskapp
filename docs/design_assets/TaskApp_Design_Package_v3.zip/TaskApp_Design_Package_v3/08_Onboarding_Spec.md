# Onboarding Spec v0.1
Backlog-style checklist: personal task → project → milestone → task → meeting import → publish verify
