-- Postgres DDL v0.3 (v3 package) — Client-safe snapshots

create extension if not exists pgcrypto;

-- Orgs / Memberships
create table if not exists organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

create table if not exists org_memberships (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('owner','member','client')),
  created_at timestamptz not null default now(),
  unique (org_id, user_id)
);

-- Spaces
create table if not exists spaces (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  type text not null check (type in ('project','personal')),
  name text not null,
  owner_user_id uuid null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  constraint spaces_personal_owner_chk check (
    (type='personal' and owner_user_id is not null) or
    (type='project' and owner_user_id is null)
  )
);

create unique index if not exists spaces_personal_unique
  on spaces(org_id, owner_user_id)
  where type='personal';

create table if not exists space_memberships (
  id uuid primary key default gen_random_uuid(),
  space_id uuid not null references spaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('admin','editor','viewer','client')),
  created_at timestamptz not null default now(),
  unique (space_id, user_id)
);

-- Milestones + snapshot publication
create table if not exists milestones (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  space_id uuid not null references spaces(id) on delete cascade,
  name text not null,
  due_date date null,
  order_key int null,
  created_at timestamptz not null default now()
);

create table if not exists milestone_publications (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  milestone_id uuid not null references milestones(id) on delete cascade,
  -- snapshot fields (client reads these)
  published_name text not null,
  published_due_date date null,
  published_order_key int null,
  is_published boolean not null default true,
  published_by uuid not null references auth.users(id),
  published_at timestamptz not null default now(),
  unique (milestone_id)
);

-- Tasks + snapshot publication
create sequence if not exists tasks_short_id_seq;

create table if not exists tasks (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  space_id uuid not null references spaces(id) on delete cascade,
  milestone_id uuid null references milestones(id) on delete set null,
  short_id bigint unique,
  title text not null,
  description text not null default '',
  status text not null check (status in ('backlog','todo','in_progress','in_review','done')),
  priority smallint not null default 1 check (priority between 0 and 3),
  assignee_id uuid null references auth.users(id),
  due_date date null,
  start_date date null,
  end_date date null,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function set_task_short_id()
returns trigger language plpgsql as $$
begin
  if new.short_id is null then
    new.short_id := nextval('tasks_short_id_seq');
  end if;
  return new;
end $$;

drop trigger if exists trg_set_task_short_id on tasks;
create trigger trg_set_task_short_id
before insert on tasks
for each row execute function set_task_short_id();

create table if not exists task_publications (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  task_id uuid not null references tasks(id) on delete cascade,
  milestone_id uuid not null references milestones(id) on delete cascade,
  -- snapshot fields (client reads these)
  published_short_id bigint not null,
  published_title text not null,
  published_status text not null,
  published_priority smallint not null,
  published_due_date date null,
  published_start_date date null,
  published_end_date date null,
  published_by uuid not null references auth.users(id),
  published_at timestamptz not null default now(),
  unique (task_id)
);

create or replace function enforce_task_publication_rules()
returns trigger language plpgsql as $$
declare t_milestone uuid;
declare pub_exists boolean;
begin
  select milestone_id into t_milestone from tasks where id = new.task_id;

  if t_milestone is null then
    raise exception 'Cannot publish a task without milestone_id';
  end if;

  if t_milestone <> new.milestone_id then
    raise exception 'task_publications.milestone_id must match tasks.milestone_id';
  end if;

  select exists(
    select 1 from milestone_publications mp
    where mp.milestone_id = new.milestone_id and mp.is_published = true
  ) into pub_exists;

  if not pub_exists then
    raise exception 'Cannot publish task: milestone is not published';
  end if;

  return new;
end $$;

drop trigger if exists trg_enforce_task_publication_rules on task_publications;
create trigger trg_enforce_task_publication_rules
before insert or update on task_publications
for each row execute function enforce_task_publication_rules();

-- Wiki + snapshot publication (already snapshot-based)
create table if not exists wiki_pages (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  space_id uuid not null references spaces(id) on delete cascade,
  title text not null,
  body text not null default '',
  created_by uuid not null references auth.users(id),
  updated_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists wiki_page_publications (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  milestone_id uuid not null references milestones(id) on delete cascade,
  source_page_id uuid not null references wiki_pages(id) on delete cascade,
  published_title text not null,
  published_body text not null,
  published_by uuid not null references auth.users(id),
  published_at timestamptz not null default now()
);

-- Discussion + comments (author_role not spoofable)
create table if not exists discussion_items (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  space_id uuid not null references spaces(id) on delete cascade,
  milestone_id uuid not null references milestones(id) on delete cascade,
  title text not null,
  body text not null default '',
  status text not null check (status in ('open','waiting_client','waiting_dev','resolved')),
  next_owner text not null check (next_owner in ('client','dev')),
  linked_task_id uuid null references tasks(id) on delete set null,
  is_client_visible boolean not null default true,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint discussion_owner_status_chk check (
    (status='waiting_client' and next_owner='client') or
    (status='waiting_dev' and next_owner='dev') or
    (status in ('open','resolved'))
  )
);

create table if not exists discussion_comments (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  discussion_id uuid not null references discussion_items(id) on delete cascade,
  author_user_id uuid not null references auth.users(id),
  author_role text not null check (author_role in ('owner','member','client')),
  body text not null,
  created_at timestamptz not null default now()
);

create or replace function set_discussion_comment_author_role()
returns trigger language plpgsql as $$
declare v_role text;
begin
  select role into v_role
  from org_memberships
  where org_id = new.org_id and user_id = auth.uid();

  if v_role is null then
    raise exception 'No org membership';
  end if;

  new.author_user_id := auth.uid();
  new.author_role := v_role;
  return new;
end $$;

drop trigger if exists trg_set_discussion_comment_author_role on discussion_comments;
create trigger trg_set_discussion_comment_author_role
before insert on discussion_comments
for each row execute function set_discussion_comment_author_role();
