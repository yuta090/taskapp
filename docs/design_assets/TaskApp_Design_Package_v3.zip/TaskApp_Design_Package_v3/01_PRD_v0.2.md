# PRD v0.2 — Task Management + Meetings + Wiki + Gantt + Client Portal

(unchanged core product intent; v3 focuses on security correctness)

## Roles
- Owner: org admin + billing + model settings.
- Member: tasks/meetings/wiki.
- Client: read published milestone/wiki/tasks + respond to discussion items (comments). No internal access.
