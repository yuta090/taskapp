-- RLS policies v0.3 — SPACE-scoped clients

alter table org_memberships enable row level security;
alter table space_memberships enable row level security;
alter table milestones enable row level security;
alter table milestone_publications enable row level security;
alter table tasks enable row level security;
alter table task_publications enable row level security;
alter table wiki_pages enable row level security;
alter table wiki_page_publications enable row level security;
alter table discussion_items enable row level security;
alter table discussion_comments enable row level security;

-- Org memberships: self only
drop policy if exists org_memberships_select_self on org_memberships;
create policy org_memberships_select_self on org_memberships
for select to authenticated
using (user_id = auth.uid());

-- Internal tasks: owner/member only (clients blocked)
drop policy if exists tasks_select_member_only on tasks;
create policy tasks_select_member_only on tasks
for select to authenticated
using (
  exists (select 1 from org_memberships m
          where m.org_id = tasks.org_id and m.user_id = auth.uid()
            and m.role in ('owner','member'))
  and exists (select 1 from space_memberships sm
              where sm.space_id = tasks.space_id and sm.user_id = auth.uid())
);

-- Internal milestones: owner/member only
drop policy if exists milestones_select_member_only on milestones;
create policy milestones_select_member_only on milestones
for select to authenticated
using (
  exists (select 1 from org_memberships m
          where m.org_id = milestones.org_id and m.user_id = auth.uid()
            and m.role in ('owner','member'))
  and exists (select 1 from space_memberships sm
              where sm.space_id = milestones.space_id and sm.user_id = auth.uid())
);

-- Publications: any org member, but SPACE-scoped via underlying milestone/task space membership
drop policy if exists milestone_publications_select_space_member on milestone_publications;
create policy milestone_publications_select_space_member on milestone_publications
for select to authenticated
using (
  exists (select 1 from org_memberships m
          where m.org_id = milestone_publications.org_id and m.user_id = auth.uid())
  and exists (
    select 1
    from milestones ms
    join space_memberships sm on sm.space_id = ms.space_id
    where ms.id = milestone_publications.milestone_id
      and sm.user_id = auth.uid()
  )
);

drop policy if exists task_publications_select_space_member on task_publications;
create policy task_publications_select_space_member on task_publications
for select to authenticated
using (
  exists (select 1 from org_memberships m
          where m.org_id = task_publications.org_id and m.user_id = auth.uid())
  and exists (
    select 1
    from tasks t
    join space_memberships sm on sm.space_id = t.space_id
    where t.id = task_publications.task_id
      and sm.user_id = auth.uid()
  )
);

drop policy if exists wiki_page_publications_select_space_member on wiki_page_publications;
create policy wiki_page_publications_select_space_member on wiki_page_publications
for select to authenticated
using (
  exists (select 1 from org_memberships m
          where m.org_id = wiki_page_publications.org_id and m.user_id = auth.uid())
  and exists (
    select 1
    from milestones ms
    join space_memberships sm on sm.space_id = ms.space_id
    where ms.id = wiki_page_publications.milestone_id
      and sm.user_id = auth.uid()
  )
);

-- Discussion items: members see all in space; clients only visible+published+client space membership
drop policy if exists discussion_items_select on discussion_items;
create policy discussion_items_select on discussion_items
for select to authenticated
using (
  exists (select 1 from org_memberships m
          where m.org_id = discussion_items.org_id and m.user_id = auth.uid())
  and (
    (
      exists (select 1 from org_memberships m2
              where m2.org_id = discussion_items.org_id and m2.user_id = auth.uid()
                and m2.role in ('owner','member'))
      and exists (select 1 from space_memberships sm
                  where sm.space_id = discussion_items.space_id and sm.user_id = auth.uid())
    )
    or
    (
      exists (select 1 from org_memberships m3
              where m3.org_id = discussion_items.org_id and m3.user_id = auth.uid()
                and m3.role = 'client')
      and exists (select 1 from space_memberships smc
                  where smc.space_id = discussion_items.space_id and smc.user_id = auth.uid()
                    and smc.role = 'client')
      and discussion_items.is_client_visible = true
      and exists (select 1 from milestone_publications mp
                  where mp.milestone_id = discussion_items.milestone_id and mp.is_published = true)
    )
  )
);

-- Discussion comments: scoped to visible discussions for clients
drop policy if exists discussion_comments_select_scoped on discussion_comments;
create policy discussion_comments_select_scoped on discussion_comments
for select to authenticated
using (
  exists (select 1 from org_memberships m
          where m.org_id = discussion_comments.org_id and m.user_id = auth.uid())
  and exists (
    select 1
    from discussion_items d
    where d.id = discussion_comments.discussion_id
      and (
        (
          exists (select 1 from org_memberships m2
                  where m2.org_id = d.org_id and m2.user_id = auth.uid()
                    and m2.role in ('owner','member'))
          and exists (select 1 from space_memberships sm
                      where sm.space_id = d.space_id and sm.user_id = auth.uid())
        )
        or
        (
          exists (select 1 from org_memberships m3
                  where m3.org_id = d.org_id and m3.user_id = auth.uid()
                    and m3.role = 'client')
          and exists (select 1 from space_memberships smc
                      where smc.space_id = d.space_id and smc.user_id = auth.uid()
                        and smc.role='client')
          and d.is_client_visible = true
          and exists (select 1 from milestone_publications mp
                      where mp.milestone_id = d.milestone_id and mp.is_published = true)
        )
      )
  )
);

drop policy if exists discussion_comments_insert_scoped on discussion_comments;
create policy discussion_comments_insert_scoped on discussion_comments
for insert to authenticated
with check (
  exists (select 1 from org_memberships m
          where m.org_id = discussion_comments.org_id and m.user_id = auth.uid())
  and exists (
    select 1
    from discussion_items d
    where d.id = discussion_comments.discussion_id
      and (
        (
          exists (select 1 from org_memberships m2
                  where m2.org_id = d.org_id and m2.user_id = auth.uid()
                    and m2.role in ('owner','member'))
          and exists (select 1 from space_memberships sm
                      where sm.space_id = d.space_id and sm.user_id = auth.uid())
        )
        or
        (
          exists (select 1 from org_memberships m3
                  where m3.org_id = d.org_id and m3.user_id = auth.uid()
                    and m3.role = 'client')
          and exists (select 1 from space_memberships smc
                      where smc.space_id = d.space_id and smc.user_id = auth.uid()
                        and smc.role='client')
          and d.is_client_visible = true
          and exists (select 1 from milestone_publications mp
                      where mp.milestone_id = d.milestone_id and mp.is_published = true)
        )
      )
  )
);
