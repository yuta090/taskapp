# UI/UX & IA Specs (v3 deltas)

- Personal route: `/[orgId]/personal` is **personal owner only**
- Client portal shows snapshot publications only (no internal tables)
