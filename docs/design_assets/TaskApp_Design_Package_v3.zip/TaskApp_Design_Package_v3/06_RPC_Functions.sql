-- RPC v0.2 (security definer with explicit auth checks)

create or replace function _assert_org_role(p_org_id uuid, p_roles text[])
returns void language plpgsql security definer as $$
begin
  perform 1 from org_memberships m
  where m.org_id = p_org_id and m.user_id = auth.uid() and m.role = any(p_roles);
  if not found then
    raise exception 'Not authorized (org role)';
  end if;
end $$;

create or replace function _assert_space_write(p_space_id uuid)
returns void language plpgsql security definer as $$
begin
  perform 1 from space_memberships sm
  where sm.space_id = p_space_id and sm.user_id = auth.uid() and sm.role in ('admin','editor');
  if not found then
    raise exception 'Not authorized (space role)';
  end if;
end $$;

create or replace function rpc_publish_milestone(p_milestone_id uuid)
returns void language plpgsql security definer set search_path = public, auth as $$
declare v_org uuid;
declare v_space uuid;
declare v_name text;
declare v_due date;
declare v_order int;
begin
  select org_id, space_id, name, due_date, order_key
    into v_org, v_space, v_name, v_due, v_order
  from milestones where id = p_milestone_id;

  if v_org is null then raise exception 'Milestone not found'; end if;

  perform _assert_org_role(v_org, array['owner','member']);
  perform _assert_space_write(v_space);

  insert into milestone_publications(org_id, milestone_id, published_name, published_due_date, published_order_key, is_published, published_by)
  values (v_org, p_milestone_id, v_name, v_due, v_order, true, auth.uid())
  on conflict (milestone_id)
  do update set
    published_name=excluded.published_name,
    published_due_date=excluded.published_due_date,
    published_order_key=excluded.published_order_key,
    is_published=true,
    published_by=auth.uid(),
    published_at=now();
end $$;

create or replace function rpc_publish_task(p_task_id uuid)
returns void language plpgsql security definer set search_path = public, auth as $$
declare v_org uuid;
declare v_space uuid;
declare v_milestone uuid;
declare v_short bigint;
declare v_title text;
declare v_status text;
declare v_priority smallint;
declare v_due date;
declare v_start date;
declare v_end date;
begin
  select org_id, space_id, milestone_id, short_id, title, status, priority, due_date, start_date, end_date
    into v_org, v_space, v_milestone, v_short, v_title, v_status, v_priority, v_due, v_start, v_end
  from tasks where id=p_task_id;

  if v_org is null then raise exception 'Task not found'; end if;
  if v_milestone is null then raise exception 'Cannot publish task without milestone'; end if;

  perform _assert_org_role(v_org, array['owner','member']);
  perform _assert_space_write(v_space);

  perform 1 from milestone_publications where milestone_id=v_milestone and is_published=true;
  if not found then raise exception 'Milestone not published'; end if;

  insert into task_publications(
      org_id, task_id, milestone_id,
      published_short_id, published_title, published_status, published_priority,
      published_due_date, published_start_date, published_end_date,
      published_by
  )
  values (
      v_org, p_task_id, v_milestone,
      v_short, v_title, v_status, v_priority,
      v_due, v_start, v_end,
      auth.uid()
  )
  on conflict (task_id) do update set
      milestone_id=excluded.milestone_id,
      published_short_id=excluded.published_short_id,
      published_title=excluded.published_title,
      published_status=excluded.published_status,
      published_priority=excluded.published_priority,
      published_due_date=excluded.published_due_date,
      published_start_date=excluded.published_start_date,
      published_end_date=excluded.published_end_date,
      published_by=auth.uid(),
      published_at=now();
end $$;
