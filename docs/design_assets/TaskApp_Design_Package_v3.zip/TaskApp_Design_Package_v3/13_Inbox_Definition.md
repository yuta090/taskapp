# Inbox Definition (MVP)
Inbox is a derived view (no notifications table):
- waiting_client discussions
- assigned-to-me urgent tasks
- linked PR events
