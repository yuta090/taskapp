# Data Model & Publishing Rationale (Client-Safe)

## Non-negotiable security model
- Client visibility is **SPACE-scoped** via `space_memberships(role='client')`.
- Client reads **snapshots only**:
  - milestone_publications (snapshot)
  - task_publications (snapshot)
  - wiki_page_publications (snapshot)
- Client must never require access to internal tables (milestones, tasks, wiki_pages, meetings, transcripts).
