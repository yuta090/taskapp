# Task App MVP - Complete Design Package (v3)

Generated: 2026-01-30
Target: AI Architect / Full-stack Developer

## What's fixed in v3 (compared to v2)
- Client access is **SPACE-scoped** (not org-wide).
- Client-visible data is served via **snapshot publications** (no joins to internal tables required).
- RLS tightened for publications + discussions/comments (clients can't read across org).
- RPC functions add explicit authorization checks (safe for `security definer`).
- Added Inbox definition (derived view; no notifications table in MVP).
- Personal space routing note corrected.

## Files
- `01_PRD_v0.2.md`
- `02_DataModel_and_Publishing.md`
- `03_DDL.sql`
- `04_RLS_policies.sql`
- `05_API_Spec_v0.1.md`
- `06_RPC_Functions.sql`
- `07_Edge_Functions_GitHub_Webhook.md`
- `08_Onboarding_Spec.md`
- `09_GitHub_Integration_Roadmap.md`
- `10_UI_UX_Design_Specs.md`
- `11_UI_Design_System_Rules.md`
- `12_NorthStar_Prototype.html` (placeholder: replace with your v2 full prototype HTML)
- `13_Inbox_Definition.md`
