# Edge Function: /github/webhook (v0.1)
- Verify signature
- Idempotency via delivery_id
- Upsert PR cache
- Auto-link by TP-<short_id>
